<?php

$servername = "localhost";
$username = "root";
$password = "@Dvtech123!";
$dbname = "EmanuelDaycare";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error)
{
  die("ERROR: Couldn't connect. " . $conn->connect_error);
}

?>
